#!/usr/bin/env python3
"""Fetch a VLESS subscription and summarize its human-readable node tags.

Uses only Python's standard library. Does not print full VLESS URIs or UUIDs.
"""
from collections import Counter
from urllib.request import Request, urlopen
import re
import sys

DEFAULT_URL = (
    "https://raw.githubusercontent.com/igareck/vpn-configs-for-russia/refs/heads/main/"
    "Vless-Reality-White-Lists-Rus-Mobile.txt"
)
COUNTRY_HINTS = {
    "🇫🇮": "Finland",
    "🇩🇪": "Germany",
    "🇳🇱": "Netherlands",
    "🇬🇧": "United Kingdom (tag only; verify endpoint)",
    "🇷🇺": "Russia (tag only; verify endpoint)",
}

def main():
    url = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_URL
    req = Request(url, headers={"User-Agent": "AntiNet-subscription-inspector/1.0"})
    try:
        with urlopen(req, timeout=20) as response:
            raw = response.read().decode("utf-8-sig", errors="replace")
    except Exception as exc:
        print(f"Не удалось получить подписку: {exc}", file=sys.stderr)
        return 1

    lines = [line.strip() for line in raw.splitlines() if line.strip()]
    vless_lines = [line for line in lines if line.lower().startswith("vless://")]
    print(f"Всего непустых строк: {len(lines)}")
    print(f"VLESS URI: {len(vless_lines)}")
    print("\nНайденные теги стран/регионов (по тексту URI):")
    found = False
    for emoji, label in COUNTRY_HINTS.items():
        count = sum(emoji in line for line in vless_lines)
        if count:
            print(f"- {emoji} {label}: {count} узлов с таким эмодзи в URI")
            found = True
    if not found:
        print("- Явные поддерживаемые эмодзи не найдены.")

    # Show only sanitized display labels, never full URI or credentials.
    labels = Counter()
    for line in vless_lines:
        if "#" in line:
            label = line.split("#", 1)[1]
            label = re.sub(r"%[0-9A-Fa-f]{2}", " ", label)
            label = re.sub(r"[^\w\s\-.,()🇫🇮🇩🇪🇳🇱🇬🇧🇷🇺]", "", label)
            label = " ".join(label.split())[:100] or "(пустой тег)"
        else:
            label = "(тег отсутствует)"
        labels[label] += 1
    print("\nТеги узлов:")
    for label, count in sorted(labels.items(), key=lambda item: item[0].casefold()):
        print(f"- {label}: {count}")
    print("\nПримечание: эмодзи и текст тега — подсказки, не геолокационная проверка IP.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
